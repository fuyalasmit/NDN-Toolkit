while true; do ndnpeek -p /ndn/fake/random-$(shuf -i 1-999999 -n 1) -w 600 & sleep 0.18; done
