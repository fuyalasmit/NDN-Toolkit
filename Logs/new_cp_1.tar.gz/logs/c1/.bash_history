ndnpeek -p /ndn/pollution/random-1
ndnpeek -p /ndn/text
ndnpeek -p /ndn/image

ndnpeek -p /ndn/pollution/random-1
ndnpeek -p /ndn/pollution/random-0
ndnpeek -p /ndn/pollution/random
ndnpeek -p /ndn/pollution/
ls
ndnpeek -p /ndn/pollution/random-0
ndnpeek -p /ndn/pollution/random-1
ndnpeek -p /ndn/pollution/random-2
ndnpeek -p /ndn/pollution/random-0
ndnpeek -p /ndn/pollution/random-3
ndnpeek -p /ndn/pollution/random-4
clear
ndnpeek -p /ndn/pollution/random-100
ndnpeek -p /ndn/pollution/random-99
clear
[200~while true; do
ndnpeek -p /ndn/pollution/random-$(shuf -i 1-99 -n 1) -w 1000 &
sleep 0.15;
while true; do ndnpeek -p /ndn/pollution/random-$(shuf -i 1-99 -n 1) -w 1000 & sleep 0.15; done
